package main

import "main/src/application"

func main() {
	app := application.New()
	app.Start()
}
